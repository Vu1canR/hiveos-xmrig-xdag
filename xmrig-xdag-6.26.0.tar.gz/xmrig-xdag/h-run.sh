#!/usr/bin/env bash
#
# h-run.sh  --  launches the miner.  Working dir is the miner folder.

XN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$XN_DIR"

# Already running?
if [[ $(ps aux | grep "$XN_DIR/xmrig" | grep -v grep | wc -l) != 0 ]]; then
    echo "xmrig-xdag is already running"
    exit 1
fi

# Regenerate config in case it is missing (h-config.sh runs from the framework,
# but make this script self-sufficient when launched directly).
[[ -e "$XN_DIR/config.json" ]] || "$XN_DIR/h-config.sh"

# HugePages tuning for RandomX (2 MB pages), if the HiveOS helper is available
if [[ -x /hive/bin/hugepages ]]; then
    echo "HugePages tuning for RandomX ..."
    hugepages -rx
fi

LOG_BASE="${CUSTOM_LOG_BASENAME:-/var/log/miner/custom/xmrig-xdag/xmrig-xdag}"
mkdir -p "$(dirname "$LOG_BASE")"

"$XN_DIR/xmrig" --config="$XN_DIR/config.json" $CUSTOM_USER_CONFIG 2>&1 \
    | tee --append "${LOG_BASE}.log"
