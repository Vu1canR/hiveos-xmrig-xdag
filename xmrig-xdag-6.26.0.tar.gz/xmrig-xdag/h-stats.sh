#!/usr/bin/env bash
#
# h-stats.sh  --  sourced by /hive/miners/custom/h-stats.sh inside the agent.
# Must define two variables: $khs (total hashrate, kH/s) and $stats (JSON).

XN_API_PORT=60050

xn_stats_raw=$(curl --connect-timeout 2 --max-time "${API_TIMEOUT:-10}" \
    --silent --noproxy '*' "http://127.0.0.1:${XN_API_PORT}/1/summary" 2>/dev/null)

if [[ $? -ne 0 || -z $xn_stats_raw ]]; then
    echo "Failed to read xmrig-xdag from localhost:${XN_API_PORT}"
    khs=0
    stats="null"
else
    khs=$(echo "$xn_stats_raw" | jq -r '.hashrate.total[0] // 0' | awk '{print $1/1000}')

    xn_ac=$(jq '.results.shares_good  // 0' <<< "$xn_stats_raw")
    xn_rj=$(( $(jq '.results.shares_total // 0' <<< "$xn_stats_raw") - $xn_ac ))
    xn_cores=$(echo "$xn_stats_raw" | jq '.hashrate.threads[][0]' | wc -l)
    xn_temp=$(cpu-temp 2>/dev/null)
    [[ -z $xn_temp ]] && xn_temp=0

    xn_temps=$(for ((i=0; i<xn_cores; i++)); do echo "$xn_temp"; done | jq -cs '.')
    xn_fans=$(for ((i=0; i<xn_cores; i++)); do echo 0;        done | jq -cs '.')
    xn_buses=$(for ((i=0; i<xn_cores; i++)); do echo null;     done | jq -cs '.')

    stats=$(echo "$xn_stats_raw" | jq \
        --arg ac "$xn_ac" --arg rj "$xn_rj" \
        --argjson temp "$xn_temps" \
        --argjson fan  "$xn_fans" \
        --argjson bus  "$xn_buses" \
        '{hs: [.hashrate.threads[][0]], $temp, $fan, ar: [$ac, $rj],
          uptime: .connection.uptime, algo: .algo, bus_numbers: $bus, ver: .version}')
fi

[[ -z $khs ]]   && khs=0
[[ -z $stats ]] && stats="null"
