#!/usr/bin/env bash
#
# h-config.sh  --  sourced by /hive/miners/custom/custom on every miner start.
# HiveOS flight-sheet variables ($CUSTOM_URL, $CUSTOM_TEMPLATE, $CUSTOM_PASS,
# $CUSTOM_ALGO, $CUSTOM_USER_CONFIG, $WORKER_NAME) are already in scope.

XN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$XN_DIR/config.json"

# ---- Flight-sheet values (fall back to XDAG defaults) --------------------
XN_POOL="${CUSTOM_URL:-stratum.xdag.org:23656}"
XN_USER="${CUSTOM_TEMPLATE:-5kAGcvtoScdUeLonrCCvHRVoRVBQZ9RLg}"
XN_PASS="${CUSTOM_PASS:-x}"
XN_ALGO="${CUSTOM_ALGO:-rx/0}"
[[ -z "$XN_ALGO" ]] && XN_ALGO="rx/0"

# strip any scheme prefix (stratum+tcp://, wss://, ...) -- XMRig wants host:port
XN_POOL="${XN_POOL#*://}"

# expand HiveOS placeholders if the server left them in place
XN_USER="${XN_USER//%WORKER_NAME%/${WORKER_NAME:-desktop}}"
XN_USER="${XN_USER//%WAL%/${WORKER_NAME:-desktop}}"

XN_RIGID="${WORKER_NAME:-desktop}"
XN_API_PORT=60050

# ---- Generate config.json -------------------------------------------------
cat > "$CONFIG_FILE" <<EOF
{
    "api": {
        "id": null,
        "worker-id": null
    },
    "http": {
        "enabled": true,
        "host": "127.0.0.1",
        "port": ${XN_API_PORT},
        "access-token": null,
        "restricted": true
    },
    "autosave": false,
    "background": false,
    "colors": false,
    "title": true,
    "randomx": {
        "init": -1,
        "init-avx2": -1,
        "mode": "auto",
        "1gb-pages": false,
        "rdmsr": true,
        "wrmsr": true,
        "cache_qos": false,
        "numa": true,
        "scratchpad_prefetch_mode": 1
    },
    "cpu": {
        "enabled": true,
        "huge-pages": true,
        "huge-pages-jit": false,
        "hw-aes": null,
        "priority": null,
        "memory-pool": false,
        "yield": true,
        "asm": true,
        "argon2-impl": null,
        "cn/0": false,
        "cn-lite/0": false
    },
    "log-file": null,
    "donate-level": 0,
    "donate-over-proxy": 0,
    "pools": [
        {
            "algo": "${XN_ALGO}",
            "coin": null,
            "url": "${XN_POOL}",
            "user": "${XN_USER}",
            "pass": "${XN_PASS}",
            "rig-id": "${XN_RIGID}",
            "nicehash": false,
            "keepalive": true,
            "enabled": true,
            "tls": false,
            "sni": false,
            "tls-fingerprint": null,
            "daemon": false,
            "socks5": null,
            "self-select": null,
            "submit-to-origin": false
        }
    ],
    "retries": 5,
    "retry-pause": 5,
    "print-time": 60,
    "dmi": true,
    "syslog": false,
    "tls": {
        "enabled": false,
        "protocols": null,
        "cert": null,
        "cert_key": null,
        "ciphers": null,
        "ciphersuites": null,
        "dhparam": null
    },
    "dns": {
        "ip_version": 0,
        "ttl": 30
    },
    "user-agent": null,
    "verbose": 0,
    "watch": true,
    "pause-on-battery": false,
    "pause-on-active": false
}
EOF
